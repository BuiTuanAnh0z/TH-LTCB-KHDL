while True:
    num = float(input("Nhập một số: "))
    if num < 0:
        break

